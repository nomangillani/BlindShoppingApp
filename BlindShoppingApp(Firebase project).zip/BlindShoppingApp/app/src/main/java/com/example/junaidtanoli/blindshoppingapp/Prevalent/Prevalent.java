package com.example.junaidtanoli.blindshoppingapp.Prevalent;

import com.example.junaidtanoli.blindshoppingapp.Model.Users;

public class Prevalent {
    public static Users currentOnlineUser;

    public static final String UserphoneKey="UserPhone";
    public static final String UserpasswordKey="Userpassword";
}
