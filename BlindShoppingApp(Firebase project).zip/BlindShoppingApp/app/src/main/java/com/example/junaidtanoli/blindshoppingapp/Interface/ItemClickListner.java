package com.example.junaidtanoli.blindshoppingapp.Interface;

import android.view.View;

public interface ItemClickListner {
    Void onClick(View view,int position, boolean isLongClick);
}
